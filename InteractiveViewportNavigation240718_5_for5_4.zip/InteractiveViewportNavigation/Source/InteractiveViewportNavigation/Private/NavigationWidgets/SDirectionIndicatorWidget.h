﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.
#pragma once

#include "BaseGizmos/GizmoElementBase.h"


class ULocalSingleClickInputBehavior;


class SDirectionIndicatorWidget : public SLeafWidget
{
public:
	SLATE_BEGIN_ARGS(SDirectionIndicatorWidget) {}
	
	SLATE_ARGUMENT(FSlateBrush*,SetBrush)
	SLATE_ARGUMENT(FEditorViewportClient*,SetEditorViewportClient)
	SLATE_ARGUMENT(FVector,SetAxisDirection)
	SLATE_ARGUMENT(FLinearColor,SetAxisColor)
	SLATE_ARGUMENT(FString,SetAxisText)
	SLATE_ARGUMENT(uint32,SetPartIdentifier)
	SLATE_ARGUMENT(bool,SetIsPositive)
	
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);

	// SWidget interface
	virtual int32 OnPaint( const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled ) const override;
	virtual FVector2D ComputeDesiredSize(float) const override;
	//virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override;
	//virtual FReply OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override;
	// End of SWidget interface
	
	//用于深度排序
	float GetLoaclDepth() const {return LoaclDepth;}
	//用于检查位置判断鼠标hover
	FVector2f GetEndpointOffset() const {return EndpointOffset;}

	FInputRayHit IsHit(const UE::Slate::FDeprecateVector2DResult& MouseScreenPos);

	void UpdateHoverState(bool bHovering, uint32 InPartIdentifier);
private:
	static TArray<FVector2d> MakeViewSpaceAxisLine(const FVector2d& Endpoint);

	static FVector MakeAxisEndpointOffset(const FRotator& ViewRotation, const FVector& WorldAxis);
	
	mutable float LoaclDepth = 0;
	mutable FVector2f EndpointOffset;

	FSlateBrush* Brush = nullptr;
	FEditorViewportClient* EditorViewportClient = nullptr;

	FVector LocalAxisDirection;
	FLinearColor LocalAxisColor;
	FString LocalAxisText;

	uint32 PartIdentifier = UGizmoElementBase::DefaultPartIdentifier;
	bool bIsHovering = false;

	bool bIsPositive = true;
};

