// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "InteractiveViewportNavigationModule.h"

#include "LevelEditor.h"

#include "EditorViewportClient.h"
#include "Tools/NavigationInteractiveTool.h"
#include "EdModeInteractiveToolsContext.h"
#include "SLevelViewport.h"
#include "NavigationWidgets/IconStyle.h"
#include "NavigationWidgets/SNavigationManagerWidget.h"
#include "Subsystems/PanelExtensionSubsystem.h"

#define LOCTEXT_NAMESPACE "BInteractiveViewportNavigationModule"

namespace DirectionIndicator
{
	const static FName ViewportExtensionIdentifier = TEXT("NavigationViewportExtension");
}
FString FInteractiveViewportNavigationModule::InteractiveToolName = TEXT("ViewportNavigation_MeasureDistanceTool");

void FInteractiveViewportNavigationModule::StartupModule()
{
	FIconStyle::InitializeIcons();

	RegisterViewportTitleButton();
}

void FInteractiveViewportNavigationModule::ShutdownModule()
{
	FIconStyle::ShutDownIcons();
	UnregisterViewportTitleButton();
	
	UnregisterOnMapChanged();
	DestroyInteractiveNavigation();
	
	UnregisterOnStartPIE();
	UnregisterOnEndPIE();
}

void FInteractiveViewportNavigationModule::RegisterViewportTitleButton()
{
	if (GEditor)
	{
		if (UPanelExtensionSubsystem* PanelExtensionSubsystem = GEditor->GetEditorSubsystem<UPanelExtensionSubsystem>())
		{
			if (!PanelExtensionSubsystem->IsPanelFactoryRegistered(DirectionIndicator::ViewportExtensionIdentifier))
			{
				FPanelExtensionFactory LevelViewportToolbarExtensionWidget;
				LevelViewportToolbarExtensionWidget.CreateExtensionWidget = FPanelExtensionFactory::FCreateExtensionWidget::CreateRaw(this,&FInteractiveViewportNavigationModule::OnExtendLevelEditorViewportToolbar);
				LevelViewportToolbarExtensionWidget.Identifier = DirectionIndicator::ViewportExtensionIdentifier;

				PanelExtensionSubsystem->RegisterPanelFactory(TEXT("LevelViewportToolBar.RightExtension"), LevelViewportToolbarExtensionWidget);
			}
		}
	}
}

void FInteractiveViewportNavigationModule::UnregisterViewportTitleButton()
{
	if (GEditor)
	{
		if (UPanelExtensionSubsystem* PanelExtensionSubsystem = GEditor->GetEditorSubsystem<UPanelExtensionSubsystem>())
		{
			PanelExtensionSubsystem->UnregisterPanelFactory(DirectionIndicator::ViewportExtensionIdentifier);
		}
	}
}

TSharedRef<SWidget> FInteractiveViewportNavigationModule::OnExtendLevelEditorViewportToolbar(FWeakObjectPtr ExtensionContext)
{
	const FCheckBoxStyle& CheckBoxStyle = FIconStyle::Get().GetWidgetStyle<FCheckBoxStyle>(FName("BoxStyle"));

	return SNew(SCheckBox)
	.Style(&CheckBoxStyle)
	.OnCheckStateChanged_Lambda([&](ECheckBoxState CheckBoxState)
	{
		switch (CheckBoxState)
		{
		case ECheckBoxState::Checked:
			StartInteractiveNavigationBehavior();
			RegisterOnMapChanged();
			DrawInteractiveNavigation();
			
			RegisterOnStartPIE();
			RegisterOnEndPIE();
			
			break;
		case ECheckBoxState::Unchecked:
			EndInteractiveNavigationBehavior();
			UnregisterOnMapChanged();
			DestroyInteractiveNavigation();

			UnregisterOnStartPIE();
			UnregisterOnEndPIE();
			break;

			default:break;
		}
	});
}

void FInteractiveViewportNavigationModule::StartInteractiveNavigationBehavior()
{
	if (UModeManagerInteractiveToolsContext* ToolsContext = GLevelEditorModeTools().GetInteractiveToolsContext();
		ensure(ToolsContext))
	{
		if(bInteractiveNavigationBehaviorRegistered == false)
		{
			TObjectPtr<UNavigationInteractiveToolBuilder> BOperaterInteractiveToolBuilder = NewObject<UNavigationInteractiveToolBuilder>();
			ToolsContext->ToolManager->RegisterToolType(FInteractiveViewportNavigationModule::InteractiveToolName, BOperaterInteractiveToolBuilder);
			bInteractiveNavigationBehaviorRegistered = true;
		}
		ToolsContext->StartTool(FInteractiveViewportNavigationModule::InteractiveToolName);
	}
}

void FInteractiveViewportNavigationModule::EndInteractiveNavigationBehavior()
{
	if (UModeManagerInteractiveToolsContext* ToolsContext = GLevelEditorModeTools().GetInteractiveToolsContext();
		ensure(ToolsContext))
	{
		if(bInteractiveNavigationBehaviorRegistered == true)
		{
			ToolsContext->EndTool(EToolShutdownType::Completed);
		}
	}
}

void FInteractiveViewportNavigationModule::RegisterOnMapChanged()
{
	OnMapChangedDelegate = FEditorDelegates::MapChange.AddLambda([&](uint32 MapChangeFlags)
	{
		StartInteractiveNavigationBehavior();
	});
}

void FInteractiveViewportNavigationModule::UnregisterOnMapChanged()
{
	if(OnMapChangedDelegate.IsValid())
	{
		FEditorDelegates::MapChange.Remove(OnMapChangedDelegate);
	}
}

void FInteractiveViewportNavigationModule::RegisterOnStartPIE()
{
	OnPIEStartedDelegate = FEditorDelegates::PostPIEStarted.AddLambda([&](const bool bIsSimulating)
	{
		EndInteractiveNavigationBehavior();
		DestroyInteractiveNavigation();
	});
}

void FInteractiveViewportNavigationModule::UnregisterOnStartPIE()
{
	if(OnPIEStartedDelegate.IsValid())
	{
		FEditorDelegates::PostPIEStarted.Remove(OnPIEStartedDelegate);
	}
}

void FInteractiveViewportNavigationModule::RegisterOnEndPIE()
{
	OnPIEEndedDelegate = FEditorDelegates::EndPIE.AddLambda([&](const bool bIsSimulating)
	{
		StartInteractiveNavigationBehavior();
		DrawInteractiveNavigation();
	});
}

void FInteractiveViewportNavigationModule::UnregisterOnEndPIE()
{
	if(OnPIEEndedDelegate.IsValid())
	{
		FEditorDelegates::EndPIE.Remove(OnPIEEndedDelegate);
	}
}

void FInteractiveViewportNavigationModule::DrawInteractiveNavigation()
{
	if(CheckViewportVerticalBox())
	{
		ViewportVerticalBox->InsertSlot(2)
		.AutoHeight()
		.Padding(FMargin(8))
		[
			SAssignNew(ManagerWidget,SNavigationManagerWidget)
		];
	}
}

void FInteractiveViewportNavigationModule::DestroyInteractiveNavigation()
{
	if(CheckViewportVerticalBox() && ManagerWidget.IsValid())
	{
		ViewportVerticalBox->RemoveSlot(ManagerWidget.ToSharedRef());
	}
}

bool FInteractiveViewportNavigationModule::CheckViewportVerticalBox()
{
	if(!ViewportVerticalBox.IsValid())
	{
		FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
	
		if(const TSharedPtr<SLevelViewport> LevelViewport = LevelEditorModule.GetFirstActiveLevelViewport();
				LevelViewport.IsValid())
		{
			if(const TWeakPtr<SViewport> Viewport = LevelViewport->GetViewportWidget();
				Viewport.IsValid()) 
			{
				if(const TSharedPtr<SWidget> Overlay = Viewport.Pin()->GetContent())/*这是overlay, 因为不用它,就不cast了*/
					{
					if(Overlay->GetChildren()->Num() > 2)
					{
						if(const TSharedPtr<SVerticalBox> VerticalBox = StaticCastSharedPtr<SVerticalBox>(Overlay->GetChildren()->GetChildAt(2).ToSharedPtr()))
						{
							ViewportVerticalBox = VerticalBox;
							return true;
						}
					}
				}
			}
		}
	}
	else { return true; }
	return false;
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FInteractiveViewportNavigationModule, BInteractiveViewportNavigationEditorMode)