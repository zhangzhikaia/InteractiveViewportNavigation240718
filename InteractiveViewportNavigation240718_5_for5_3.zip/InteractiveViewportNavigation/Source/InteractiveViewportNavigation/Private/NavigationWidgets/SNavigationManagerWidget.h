﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.
#pragma once

#include "InputState.h"
#include "EditorGizmos/TransformGizmo.h"


class SDirectionIndicatorWidget;

class SNavigationManagerWidget : public SOverlay
{
public:
	
	//轴颜色
	static constexpr FColor DIAxisColorX = FColor(200, 46, 74);
	static constexpr FColor DIAxisColorY = FColor(113, 160, 22);
	static constexpr FColor DIAxisColorZ = FColor(44, 141, 254);
	
	static constexpr float AxisLength = 32.f;
	
	inline static const FVector2f OffsetToCenter = FVector2f(AxisLength*2);
	inline static const FVector2D DesiredSize = FVector2D(OffsetToCenter*2);
	
	inline static const FSlateFontInfo SlateFontInfo = FCoreStyle::Get().GetFontStyle(FName("EmbossedText"));
	inline static const FVector2f TextOffset = FVector2f(-4.f,-6.5f);

	static constexpr uint8 ElementsNum = 6;
	
	SLATE_BEGIN_ARGS(SNavigationManagerWidget) {}

	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);
	//virtual int32 OnPaint( const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled ) const override;
	virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override;

	TSharedRef<class SScaleBox> MakeNavigationElement(TSharedPtr<SDirectionIndicatorWidget> NavigationElement, FSlateBrush* InBrush, FEditorViewportClient* EditorViewportClient, FVector AxisDirection, FColor AxisColor, FString ShowText, ETransformGizmoPartIdentifier PartIdentifier);
	
	FInputRayHit IsHit(const UE::Slate::FDeprecateVector2DResult& MouseScreenPos);
	
	void UpdateHoverState(bool bHovering, uint32 PartIdentifier);
	
private:
	//子元素即用于渲染各轴向的widget
	TArray<TSharedPtr<SDirectionIndicatorWidget>> NavigationElements;
	
	//各子元素的slot, 排序设置zorder
	TArray<FOverlaySlot*> AxisSlots;
	
	//保存SortDepth为成员变量, 排序时基于深度排列FOverlaySlot
	TArray<TPair<float,FOverlaySlot*>> SortDepth;
	
};
