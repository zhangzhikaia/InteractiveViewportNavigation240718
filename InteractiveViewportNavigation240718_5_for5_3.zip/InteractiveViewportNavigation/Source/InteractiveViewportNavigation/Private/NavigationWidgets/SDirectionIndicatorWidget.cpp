﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.
#include "SDirectionIndicatorWidget.h"

#include "InteractiveNavigationUtils.h"
#include "SNavigationManagerWidget.h"
#include "VectorTypes.h"
#include "Styling/SlateBrush.h"

void SDirectionIndicatorWidget::Construct(const FArguments& InArgs)
{
	Brush = InArgs._SetBrush;
	EditorViewportClient = InArgs._SetEditorViewportClient;
	
	LocalAxisDirection = InArgs._SetAxisDirection;
	LocalAxisColor = InArgs._SetAxisColor;
	LocalAxisText = InArgs._SetAxisText;

	PartIdentifier = InArgs._SetPartIdentifier;
	bIsPositive = InArgs._SetIsPositive;
}

int32 SDirectionIndicatorWidget::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry,const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId,const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	if(EditorViewportClient == nullptr) return LayerId;
	const FRotator& ViewRotation = EditorViewportClient->GetViewRotation();

	const FVector Combine = MakeAxisEndpointOffset(ViewRotation,LocalAxisDirection);

	EndpointOffset = FVector2f(Combine.X,Combine.Y);
	LoaclDepth = Combine.Z;

	float ColorLightness = LoaclDepth;
	ColorLightness *= -0.015625f;
	ColorLightness += 1.f;
	
	const TArray<FVector2d> LineX = MakeViewSpaceAxisLine(FVector2d(EndpointOffset));
	//EndpointOffsetX += SManagerWidget::OffsetToCenter + TextOffset;

	//在5.4与5.2版本绘制顺序不一样, 5.4中先绘制的在上层, 5.2则是后绘制的在上层
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION == 4
	if(bIsPositive || bIsHovering)
	{
		FSlateDrawElement::MakeText(
		OutDrawElements,
		LayerId,
		AllottedGeometry.ToPaintGeometry(FSlateLayoutTransform(EndpointOffset + SNavigationManagerWidget::OffsetToCenter + SNavigationManagerWidget::TextOffset)),
		LocalAxisText,
		SNavigationManagerWidget::SlateFontInfo,
		ESlateDrawEffect::None,
		bIsHovering? FLinearColor::White: FLinearColor::Black
		);
	}
#endif
	
	FSlateDrawElement::MakeBox(
		OutDrawElements,
		LayerId,
		AllottedGeometry.ToPaintGeometry(FSlateLayoutTransform(EndpointOffset)),
		Brush,
		ESlateDrawEffect::None,
		LocalAxisColor * ColorLightness);
	
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION < 4
	if(bIsPositive || bIsHovering)
	{
		FSlateDrawElement::MakeText(
		OutDrawElements,
		LayerId,
		AllottedGeometry.ToPaintGeometry(FSlateLayoutTransform(EndpointOffset + SNavigationManagerWidget::OffsetToCenter + SNavigationManagerWidget::TextOffset)),
		LocalAxisText,
		SNavigationManagerWidget::SlateFontInfo,
		ESlateDrawEffect::None,
		bIsHovering? FLinearColor::White: FLinearColor::Black
		);
	}
#endif
	
	if(bIsPositive)
	{
		FSlateDrawElement::MakeLines(
		OutDrawElements,
		LayerId,
		AllottedGeometry.ToPaintGeometry(FSlateLayoutTransform(SNavigationManagerWidget::OffsetToCenter)),
		LineX,
		ESlateDrawEffect::None,
		LocalAxisColor * ColorLightness
		);
	}
	
	return LayerId;
}

FVector2D SDirectionIndicatorWidget::ComputeDesiredSize(float) const
{
	//固定范围为64,64
	return SNavigationManagerWidget::DesiredSize;
}

TArray<FVector2d> SDirectionIndicatorWidget::MakeViewSpaceAxisLine(const FVector2d& Endpoint)
{
	TArray<FVector2d> Line ;
	Line.AddUninitialized(2);
	Line[0] = FVector2d::ZeroVector;
	Line[1] = Endpoint;

	return Line;
}

FVector SDirectionIndicatorWidget::MakeAxisEndpointOffset(const FRotator& ViewRotation, const FVector& WorldAxis)
{
	//将世界方向考虑为camera空间的方向
	const FVector LocalAxis = ViewRotation.UnrotateVector(WorldAxis);

	//忽略X方向的分量, 因为深度体现不在view上(实际的camera空间Z是向前轴, 不过这里不考虑, 按显示的gizmo考虑
	//如果是材质中, camera space是按照z为向前轴的, 就要忽略Z通道了
	
	//把深度保存下来, 在父组件中排序
	//LocalAxis.Y > 屏幕X ,LocalAxis.Z*-1.f > 屏幕Y, LocalAxis.X > 屏幕深度
	const FVector Combine = FVector(LocalAxis.Y,LocalAxis.Z*-1.f,LocalAxis.X);
		
	return Combine;
}

FInputRayHit SDirectionIndicatorWidget::IsHit(const UE::Slate::FDeprecateVector2DResult& MouseScreenPos)
{
	const FVector2f Center = GetTickSpaceGeometry().GetAbsolutePosition() + SNavigationManagerWidget::OffsetToCenter;
	const float DistanceX = UE::Geometry::DistanceSquared(Center + EndpointOffset,MouseScreenPos);
	
	if(DistanceX < 100)
	{
		FInputRayHit RayHit(static_cast<float>(LoaclDepth));
		RayHit.HitIdentifier = PartIdentifier;
		return RayHit;
	}
	
	return FInputRayHit();
}

void SDirectionIndicatorWidget::UpdateHoverState(bool bHovering, uint32 InPartIdentifier)
{
	if(PartIdentifier == InPartIdentifier)
	{
		bIsHovering = bHovering;
	}
	
}